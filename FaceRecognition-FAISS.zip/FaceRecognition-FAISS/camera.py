import cv2
import threading
import time

class ThreadedCamera:
    def __init__(self, src=0):
        self.src = src
        self.cap = None
        self.frame = None
        self.running = False
        self.thread = None
        self.lock = threading.Lock()
        self.status = "Disconnected" # Disconnected, Connecting, Connected, Error

    def start(self):
        if not self.running:
            self.running = True
            self.thread = threading.Thread(target=self.update, daemon=True)
            self.thread.start()

    def update(self):
        while self.running:
            # Check running flag at the start of each iteration
            if not self.running:
                break
                
            if self.cap is None or not self.cap.isOpened():
                # Check running flag before attempting reconnection
                if not self.running:
                    break
                    
                self.status = "Connecting"
                try:
                    # Attempt to connect
                    print(f"📷 Camera: Connecting to {self.src}...")
                    self.cap = cv2.VideoCapture(self.src)
                    
                    # Check if connection was successful
                    if self.cap.isOpened():
                        self.status = "Connected"
                        print(f"✅ Camera: Connected to {self.src}")
                    else:
                        self.status = "Error"
                        print(f"❌ Camera: Failed to connect to {self.src}")
                        time.sleep(2) # Wait before retrying
                        continue
                except Exception as e:
                    self.status = "Error"
                    print(f"❌ Camera: Error connecting: {e}")
                    time.sleep(2)
                    continue

            # Read frame
            try:
                ret, frame = self.cap.read()
                if ret:
                    with self.lock:
                        self.frame = frame
                    self.status = "Connected"
                else:
                    # If read fails, release and retry loop will handle reconnection
                    print("⚠️ Camera: Failed to read frame. Reconnecting...")
                    self.status = "Error"
                    self.cap.release()
                    self.cap = None
                    time.sleep(1)
            except Exception as e:
                print(f"❌ Camera: Error reading frame: {e}")
                self.status = "Error"
                if self.cap:
                    self.cap.release()
                    self.cap = None
                time.sleep(1)
            
            # Small sleep to prevent CPU hogging if loop is tight
            time.sleep(0.005)
        
        # Cleanup when exiting loop
        print("🛑 Camera: Thread stopping, releasing resources...")
        if self.cap:
            self.cap.release()
            self.cap = None
        self.status = "Disconnected"
        print("✅ Camera: Resources released") 

    def get_frame(self):
        with self.lock:
            return self.frame

    def get_status(self):
        return self.status

    def stop(self):
        print("🛑 Camera: Stopping...")
        self.running = False
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=2.0)
        if self.cap:
            self.cap.release()
            self.cap = None
        self.status = "Disconnected"
        self.frame = None
        print("✅ Camera: Stopped successfully")